/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ejemploclasep7;

import java.util.concurrent.Callable;
import java.util.logging.Level;
import java.util.logging.Logger;

public class ConRetorno implements Callable<Integer> {

    private final int id;

    public ConRetorno(int id) {
        this.id = id;
    }

    @Override
    public Integer call() throws Exception {
        for (int i = 0; i < 3; i++) {
            try {
                System.out.println("soy la tarea " + id + "corriendo en el hilo " + Thread.currentThread().getName());
                Thread.sleep(1000);
            } catch (InterruptedException ex) {
                System.out.println("tarea " + id + " recibe orden de parar");
            }
        }
        return id*1000;
    }

}
