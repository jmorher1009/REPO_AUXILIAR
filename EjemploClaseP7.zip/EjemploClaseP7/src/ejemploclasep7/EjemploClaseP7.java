/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejemploclasep7;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class EjemploClaseP7 {

    public static void main(String[] args) throws InterruptedException, ExecutionException {
        // TODO code application logic here
        //Thread[] hilos = new Thread[5];
        ExecutorService thp = Executors.newFixedThreadPool(3);
        Future[] idI = new Future[5];
        for (int i = 0; i < 5; i++) {
            //SinRetorno r = new SinRetorno(i);
            ConRetorno r = new ConRetorno(i);
            idI[i] = thp.submit(r); // sitio donde se va a almacenar el dato
        }

        thp.shutdown();//finaliza threadpool una vez haya acabado
        /*SinRetorno d = new SinRetorno(1);
        thp.submit(d);
         */
        //NO SE PUEDE HACER SUBMIT
        for (int i = 0; i < 5; i++) {
            System.out.println((int) idI[i].get());
        }
        System.out.println("Fin de la main");
    }

}
